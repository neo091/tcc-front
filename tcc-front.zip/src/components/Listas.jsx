const Listas = () => {
    return (
        <>

            <ul>
                <li>Item1</li>
                <li>Item2</li>
                <li>Item3</li>
                <li>Item4</li>
            </ul>
        </>
    )
}

export default Listas