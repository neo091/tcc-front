const Title = () => {

    const config = {
        type: type || 'h2'
    }



    return (
        <>
        </>
    );
}

export default Title;