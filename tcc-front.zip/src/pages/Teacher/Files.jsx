const Files = () => {
    return (<>Files</>);
}

export default Files;