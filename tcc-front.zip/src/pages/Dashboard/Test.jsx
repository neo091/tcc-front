import { useEffect, useState } from "react";
import Enlace from "../../components/Enlace";

const InglishTest = () => {

    //json de las preguntas con sus respeectivas respuestas
    const testJSON = [
        {
            "title": "What is the correct form of the verb in the following sentence:",
            "question": "She _____ to the store every day.?",
            "options": [
                "a) go",
                "b) goes",
                "c) going",
                "d) gone"
            ],
            "answer": "b) goes"
        },
        {
            "title": "Choose the correct option:",
            "question": "I have been working here _____ 2015.",
            "options": [
                "a) for",
                "b) since",
                "c) from",
                "d) until"
            ],
            "answer": "b) since"
        },
        {
            "title": "Choose the correct option:",
            "question": "Which of the following sentences is grammatically correct?",
            "options": [
                "a) She don't like pizza.",
                "b) She doesn't likes pizza.",
                "c) She doesn't like pizza.",
                "d) She not likes pizza."
            ],
            "answer": "c) She doesn't like pizza."
        },
        {
            "title": "Fill in the blank:",
            "question": "If I _____ rich, I would travel the world.",
            "options": [
                "a) am",
                "b) was",
                "c) were",
                "d) be"
            ],
            "answer": "c) were"
        },
        {
            "title": "Choose the correct word to complete the sentence:",
            "question": "He is the _____ person I have ever met.",
            "options": [
                "a) kinder",
                "b) kindest",
                "c) more kind",
                "d) most kind"
            ],
            "answer": "b) kindest"
        }
    ]

    const [tests, setTests] = useState([])
    const [currentQuestion, setCurrenQuestion] = useState(0)
    const [answered, setAnswered] = useState([])

    useEffect(() => {
        setTests(testJSON)
    }, [])

    const nextHandle = (e) => {
        const current = currentQuestion + 1

        if (current > tests.length) {
            return
        }

        setAnswered([...answered, e.target.innerText])
        setCurrenQuestion(current)
    }

    const resetHandle = () => {
        setCurrenQuestion(0)
    }

    return (

        <>
            {
                answered.length === testJSON.length ? answered : ""
            }
            <div className=" w-full lg:w-1/3 mx-auto bg-slate-800 p-4 rounded">
                <p>{currentQuestion + 1} / {tests.length}: <span className=" text-2xl">{tests[currentQuestion]?.question}</span></p>
                <p>{tests[currentQuestion]?.options.map(option => (
                    <button key={option} onClick={(e) => nextHandle(e)} className=" bg-violet-600 hover:bg-violet-700 rounded block w-full text-center my-2 font-semibold text-white p-4 transition-all duration-500">{option}</button>
                ))}</p>


                <div className="my-2 bg-slate-500 p-1"></div>

                <Enlace to={""} modal handle={resetHandle}>Reset</Enlace>
            </div>



        </>
    );
}

export default InglishTest;