const Separador = () => {
    return (
        <div className="my-5 border-violet-950 border-t-2"></div>
    );
}

export default Separador;