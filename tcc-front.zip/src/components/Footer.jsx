const Footer = () => {
    return (
        <>
            <footer className="bg-black text-white position-fixed ">
                <div className="w-2/3 mx-auto ">
                    <p>Footer</p>
                </div>
            </footer>
        </>
    )
}

export default Footer