const TeacherHome = () => {
    return (<>TeacherHome</>);
}

export default TeacherHome;