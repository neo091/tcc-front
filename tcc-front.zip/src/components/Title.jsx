const Title = ({ children }) => {
    return (
        <>

            <h1 className="text-3xl w-full">{children}</h1>

        </>
    );
}

export default Title;