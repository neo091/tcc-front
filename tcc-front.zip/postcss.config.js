export default {
    plugins: {
        tailwindcss: {}
    },
}