const FormControl = ({ children }) => {
    return (
        <>

            <div className="my-2 text-black w-1/3">
                {children}
            </div>

        </>
    )
}

export default FormControl