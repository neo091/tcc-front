import { Outlet } from 'react-router-dom';


const Rooms = () => {
    return (
        <>
            <Outlet />
        </>
    );
}

export default Rooms;